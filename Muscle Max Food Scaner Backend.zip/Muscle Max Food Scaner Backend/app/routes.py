from flask import Blueprint, request, jsonify
from .utils import process_food_image

main = Blueprint('main', __name__)

# ✅ New route so browser shows something at "/"
@main.route('/', methods=['GET'])
def index():
    return jsonify({"message": "✅ Food Scanner API is running!"})

# ✅ Existing /scan-food POST route
@main.route('/scan-food', methods=['POST'])
def scan_food():
    if 'image' not in request.files:
        return jsonify({'error': 'No image uploaded'}), 400

    image = request.files['image']
    
    # Call your processing logic
    result = process_food_image(image)

    return jsonify(result)
