def process_food_image(image):
    # 👉 In future: call Edamam / CalorieMama / custom model here
    # For now, return mock data
    return {
        "food": "Sample Meal",
        "calories": 450,
        "protein": "25g",
        "carbs": "50g",
        "fats": "20g"
    }
